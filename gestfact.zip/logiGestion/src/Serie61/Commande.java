package Serie61;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Commande {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Commande window = new Commande();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Commande() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 218, 185));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblGestionDesCommandes = new JLabel("Gestion des commandes");
		lblGestionDesCommandes.setBounds(99, 25, 236, 28);
		lblGestionDesCommandes.setForeground(new Color(25, 25, 112));
		lblGestionDesCommandes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 24));
		panel.add(lblGestionDesCommandes);
		
		JButton btnNewButton = new JButton(">>Créer une commande");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.setFont(new Font("Times New Roman", Font.ITALIC, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EcpaceClient ec = new EcpaceClient();
				ec.NewScreen();
				
				
			}
		});
		btnNewButton.setBounds(69, 83, 231, 28);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton(">>Modifier une commande");
		btnNewButton_1.setFont(new Font("Times New Roman", Font.ITALIC, 14));
		btnNewButton_1.setForeground(Color.BLUE);
		btnNewButton_1.setBounds(69, 136, 231, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton(">>Supprimer une commande");
		btnNewButton_2.setForeground(Color.BLUE);
		btnNewButton_2.setFont(new Font("Times New Roman", Font.ITALIC, 14));
		btnNewButton_2.setBounds(69, 186, 231, 23);
		panel.add(btnNewButton_2);
	}
}
