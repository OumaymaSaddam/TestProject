package Serie61;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EcpaceClient {

	private JFrame frame;
	private JTextField nomPrenom;
	private JTable table;
	
	Connection cnx = null;
	PreparedStatement prepared =null;
	ResultSet resultat = null; 
	private JTable table_1;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EcpaceClient window = new EcpaceClient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void NewScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EcpaceClient window = new EcpaceClient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EcpaceClient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 545, 436);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		cnx = MyCnx.ConnexionDB();
		
		JLabel lblNewLabel = new JLabel("Espace client");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 26));
		lblNewLabel.setBounds(209, 11, 156, 31);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel nomprenom = new JLabel("Nom&Prénom");
		nomprenom.setFont(new Font("Times New Roman", Font.ITALIC, 20));
		nomprenom.setBounds(41, 69, 115, 14);
		frame.getContentPane().add(nomprenom);
		
		nomPrenom = new JTextField();
		nomPrenom.setBounds(203, 69, 120, 20);
		frame.getContentPane().add(nomPrenom);
		nomPrenom.setColumns(10);
		
		JButton btnSuivant = new JButton("Vérifier");
		btnSuivant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UpdateTable();
				
				// String query="INSERT INTO clients(nomC)"+ "VALUES(?)";
			     //   try{
			            
			        	//prepared = MyCnx.ConnexionDB().prepareStatement(query);
			        	//prepared.setString(1, nomPrenom.getText());
			            

			        //	prepared.execute();
			          //  JOptionPane.showMessageDialog(null, "inscrit avec succé");
			      //  }
			      //  catch(Exception ex){
			                  //  JOptionPane.showMessageDialog(null, ex);
			      //  }

				
				    String name = nomPrenom.getText().toString();
				    
			        String query ="Select nomC from clients ";

				
				//String sql = " select nomC from clients";
				  try {
					  
					  prepared = cnx.prepareStatement(query);
			            
					  //prepared.setString(1, name);
			          resultat = prepared.executeQuery();
			          
			          int i=0;
			          while(resultat.next()) {
			  			
					        String nomPrenom=resultat.getString("nomC");
					       
					       if(nomPrenom.equals(name) )
					       {   i=1;
					        	JOptionPane.showMessageDialog(null, "connetion reussite");
					        		
								}
			          }}
				  
					
					//prepared = cnx.prepareStatement(query);
					//resultat = prepared.executeQuery();
					//int i = 0;
					//while (resultat.next()) {
						
						//String name1 = resultat.getString(name);
						//if (name1.contentEquals(name))
						//{
							//JOptionPane.showMessageDialog(null, "reussite");
						//
					//}
					//JOptionPane.showMessageDialog(null, i);
					
					
					
			 catch (SQLException e) {
					
				e.printStackTrace();
				
			 }}});
			
				
			
		
		btnSuivant.setBounds(401, 68, 89, 23);
		frame.getContentPane().add(btnSuivant);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(41, 142, 449, 160);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JButton btnAfficher = new JButton("Afficher");
		btnAfficher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				UpdateTable();
				
			}
		});
		btnAfficher.setBounds(55, 108, 89, 23);
		frame.getContentPane().add(btnAfficher);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(41, 338, 449, 48);
		frame.getContentPane().add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		JButton btnPasser = new JButton("Passer");
		btnPasser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int ligne = table.getSelectedRow();
				String code = table.getModel().getValueAt(ligne, 0).toString();
		        String sql ="INSERT INTO commande (code,nom,prix,etat)" +"VALUES (?,?,?,?)" ;
             try {
            	 prepared = cnx.prepareStatement(sql);
            	 prepared.execute();
            	 
            	 
            	 
             }
             catch(SQLException e) {
            	 e.printStackTrace();
             }
				
			}
		});
		btnPasser.setBounds(430, 313, 89, 23);
		frame.getContentPane().add(btnPasser);
		
		
		
		
		}
	public void UpdateTable() {
		String sql = "select *  from article";
		try {
			prepared = cnx.prepareStatement(sql);
			
			resultat =  prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}
}

	
		
	
	

