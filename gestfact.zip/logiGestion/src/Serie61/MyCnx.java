package Serie61;



import javax.swing.*;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.sql.*;


public class MyCnx {
	

	Connection cnx = null;
	
	  public static Connection ConnexionDB() {
   
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection cnx = DriverManager.getConnection("jdbc:mysql://localhost:3308/gestion_commande","root","");
        	return cnx;
        	
        
        } catch (Exception e) {
        	JOptionPane.showMessageDialog(null, e);
        	return null;
        }
        }
        
      
    }


