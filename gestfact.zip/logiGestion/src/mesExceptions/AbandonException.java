package mesExceptions;

public class AbandonException extends Exception{

	private static final long serialVersionUID = 1L;

}
