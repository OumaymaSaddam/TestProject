package mesExceptions;

public class ErreurSaisie extends Exception{

	private static final long serialVersionUID = 1L;

}
